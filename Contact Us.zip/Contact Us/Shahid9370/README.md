- 👋 Hi, I’m @Shahid
- 👀 I’m interested in technology 
- 🌱 I’m currently learning web technology
- 💞️ I’m looking to collaborate on it / coding project
- 📫 How to reach me shahidsrs93@gmail.com
- 😄 Pronouns: Sha hid
- ⚡ Fun fact: Solving puzzles

<!---
Shahid9370/Shahid9370 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
